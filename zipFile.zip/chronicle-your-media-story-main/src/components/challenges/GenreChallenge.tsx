export { GenreChallenge } from "./Challenges";
