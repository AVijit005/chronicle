// Contextual verbs for any media item. Frontend-only — drives the live library store.
import { useMemo, useState } from "react";
import {
  Heart,
  Play,
  Pause,
  Check,
  RotateCcw,
  Archive,
  Bookmark,
  NotebookPen,
  Plus,
  Trash2,
  MoreHorizontal,
  Quote,
  Sparkles,
  ListPlus,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";
import { useLibraryStore } from "@/lib/store/libraryStore";
import { useMediaActions } from "@/lib/store/MediaActionsContext";
import { toggleBookmark, isBookmarked } from "@/lib/bookmarks";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "@/components/ui/dropdown-menu";

interface Props {
  id: string;
  title: string;
  variant?: "inline" | "overlay" | "hero";
  className?: string;
}

interface Verb {
  key: string;
  label: string;
  icon: LucideIcon;
  run: () => void;
  primary?: boolean;
  danger?: boolean;
}

export function ItemActionBar({ id, title, variant = "inline", className }: Props) {
  const navigate = useNavigate();
  const meta = useLibraryStore((s) => s.meta[id]);
  const collections = useLibraryStore((s) => s.collections);
  const setStatus = useLibraryStore((s) => s.setStatus);
  const toggleFavorite = useLibraryStore((s) => s.toggleFavorite);
  const incrementRewatch = useLibraryStore((s) => s.incrementRewatch);
  const removeItem = useLibraryStore((s) => s.removeItem);
  const createCollection = useLibraryStore((s) => s.createCollection);
  const toggleCollectionItem = useLibraryStore((s) => s.toggleCollectionItem);
  const { openProgress, openReflection } = useMediaActions();
  const [bookmarked, setBookmarked] = useState(() => isBookmarked("media", id));

  const status = meta?.status;
  const fav = !!meta?.favorite;

  function s(next: typeof status, msg: string) {
    if (!next) return;
    setStatus(id, next);
    toast.success(msg, { description: title });
  }

  const verbs = useMemo<Verb[]>(() => {
    if (!status)
      return [
        {
          key: "plan",
          label: "Save to Planning",
          icon: Plus,
          run: () => s("planning", "Saved to Planning"),
          primary: true,
        },
        {
          key: "start",
          label: "Start now",
          icon: Play,
          run: () => s("in_progress", "Journey started"),
        },
      ];
    const v: Verb[] = [];
    if (status === "planning") {
      v.push({
        key: "start",
        label: "Start journey",
        icon: Play,
        run: () => s("in_progress", "Journey started"),
        primary: true,
      });
      v.push({
        key: "pause",
        label: "Move to Paused",
        icon: Pause,
        run: () => s("paused", "Moved to Paused"),
      });
    }
    if (status === "in_progress" || status === "rewatching") {
      v.push({
        key: "log",
        label: "Log progress",
        icon: Sparkles,
        run: () => openProgress(id),
        primary: true,
      });
      v.push({ key: "pause", label: "Pause", icon: Pause, run: () => s("paused", "Paused") });
      v.push({
        key: "done",
        label: "Complete",
        icon: Check,
        run: () => {
          s("completed", "Marked complete");
          setTimeout(() => openReflection(id), 60);
        },
      });
    }
    if (status === "paused") {
      v.push({
        key: "resume",
        label: "Resume",
        icon: Play,
        run: () => s("in_progress", "Resumed"),
        primary: true,
      });
      v.push({ key: "drop", label: "Drop", icon: Trash2, run: () => s("dropped", "Dropped") });
      v.push({
        key: "done",
        label: "Mark complete",
        icon: Check,
        run: () => {
          s("completed", "Marked complete");
          setTimeout(() => openReflection(id), 60);
        },
      });
    }
    if (status === "completed") {
      v.push({
        key: "rewatch",
        label: "Rewatch",
        icon: RotateCcw,
        run: () => {
          incrementRewatch(id);
          toast.success("Rewatch started", { description: title });
        },
        primary: true,
      });
      v.push({
        key: "reflect",
        label: "Reflect",
        icon: NotebookPen,
        run: () => openReflection(id),
      });
      v.push({
        key: "archive",
        label: "Archive",
        icon: Archive,
        run: () => s("archived", "Archived"),
      });
    }
    if (status === "dropped") {
      v.push({
        key: "restart",
        label: "Restart",
        icon: Play,
        run: () => s("in_progress", "Restarted"),
        primary: true,
      });
      v.push({
        key: "archive",
        label: "Archive",
        icon: Archive,
        run: () => s("archived", "Archived"),
      });
    }
    if (status === "archived") {
      v.push({
        key: "restore",
        label: "Restore",
        icon: RotateCcw,
        run: () => s("in_progress", "Restored"),
        primary: true,
      });
    }
    return v;
  }, [status, id, title]);

  const primary = verbs.filter((v) => v.primary);
  const secondary = verbs.filter((v) => !v.primary);

  // Style per variant
  const wrap = cn(
    "flex items-center gap-1.5",
    variant === "overlay" &&
      "rounded-full bg-black/55 px-1.5 py-1 backdrop-blur-md ring-1 ring-white/10",
    variant === "hero" && "flex-wrap gap-2",
    className,
  );

  return (
    <div className={wrap} onClick={(e) => e.stopPropagation()}>
      {primary.map((v) => (
        <button
          key={v.key}
          onClick={v.run}
          className={cn(
            "press-scale inline-flex items-center gap-1.5 rounded-full text-xs font-medium",
            variant === "hero"
              ? "bg-gradient-to-r from-primary to-secondary px-4 py-2 text-sm text-primary-foreground"
              : variant === "overlay"
                ? "bg-white/95 px-3 py-1.5 text-foreground"
                : "bg-gradient-to-r from-primary to-secondary px-3 py-1.5 text-primary-foreground",
          )}
        >
          <v.icon className="h-3.5 w-3.5" /> {v.label}
        </button>
      ))}

      <button
        onClick={() => {
          toggleFavorite(id);
          toast(fav ? "Removed from favorites" : "Favorited", { description: title });
        }}
        aria-label="Favorite"
        aria-pressed={fav}
        className={cn(
          "press-scale grid h-8 w-8 place-items-center rounded-full ring-1 ring-white/10 transition",
          fav
            ? "bg-rose-500/20 text-rose-300"
            : "bg-white/[0.06] text-muted-foreground hover:text-foreground",
        )}
      >
        <Heart className={cn("h-3.5 w-3.5", fav && "fill-current")} />
      </button>

      <button
        onClick={() => {
          const v = toggleBookmark({ kind: "media", refId: id, title, to: `/app/media/${id}` });
          setBookmarked(v);
          toast(v ? "Bookmarked" : "Bookmark removed");
        }}
        aria-label="Bookmark"
        aria-pressed={bookmarked}
        className={cn(
          "press-scale grid h-8 w-8 place-items-center rounded-full ring-1 ring-white/10 transition",
          bookmarked
            ? "bg-primary/15 text-primary"
            : "bg-white/[0.06] text-muted-foreground hover:text-foreground",
        )}
      >
        <Bookmark className={cn("h-3.5 w-3.5", bookmarked && "fill-current")} />
      </button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            aria-label="More actions"
            className="press-scale grid h-8 w-8 place-items-center rounded-full bg-white/[0.06] text-muted-foreground ring-1 ring-white/10 hover:text-foreground"
          >
            <MoreHorizontal className="h-3.5 w-3.5" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            {title}
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          {secondary.map((v) => (
            <DropdownMenuItem
              key={v.key}
              onSelect={v.run}
              className={cn(v.danger && "text-rose-300 focus:text-rose-200")}
            >
              <v.icon className="mr-2 h-4 w-4" />
              {v.label}
            </DropdownMenuItem>
          ))}
          {secondary.length > 0 && <DropdownMenuSeparator />}
          <DropdownMenuItem onSelect={() => navigate({ to: "/app/journal" })}>
            <NotebookPen className="mr-2 h-4 w-4" />
            Add journal entry
          </DropdownMenuItem>
          <DropdownMenuItem
            onSelect={() => {
              const text = window.prompt(`Save a quote from ${title}`);
              if (text?.trim()) {
                useLibraryStore.getState().addUserQuote(text.trim(), { id, title });
                toast.success("Quote saved", { description: title });
              }
            }}
          >
            <Quote className="mr-2 h-4 w-4" />
            Save a quote
          </DropdownMenuItem>
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>
              <ListPlus className="mr-2 h-4 w-4" />
              Add to collection
            </DropdownMenuSubTrigger>
            <DropdownMenuSubContent className="w-56">
              {collections.length === 0 && (
                <div className="px-2 py-1.5 text-xs text-muted-foreground">No collections yet</div>
              )}
              {collections.map((c) => (
                <DropdownMenuItem
                  key={c.id}
                  onSelect={() => {
                    toggleCollectionItem(c.id, id);
                    toast.success(
                      c.itemIds.includes(id) ? `Removed from ${c.name}` : `Added to ${c.name}`,
                    );
                  }}
                >
                  {c.itemIds.includes(id) ? (
                    <Check className="mr-2 h-4 w-4 text-primary" />
                  ) : (
                    <span className="mr-2 inline-block h-4 w-4" />
                  )}
                  {c.name}
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onSelect={() => {
                  const name = window.prompt("New collection name");
                  if (name?.trim()) {
                    const cid = createCollection(name.trim());
                    toggleCollectionItem(cid, id);
                    toast.success(`Added to ${name.trim()}`);
                  }
                }}
              >
                <Plus className="mr-2 h-4 w-4" />
                New collection…
              </DropdownMenuItem>
            </DropdownMenuSubContent>
          </DropdownMenuSub>
          {status && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onSelect={() => {
                  removeItem(id);
                  toast("Removed from library", { description: title });
                }}
                className="text-rose-300 focus:text-rose-200"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Remove from library
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
